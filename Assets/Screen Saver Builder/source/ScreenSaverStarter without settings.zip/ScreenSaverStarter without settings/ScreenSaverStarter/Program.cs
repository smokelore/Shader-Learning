﻿using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Windows.Forms;

namespace ScreenSaverStarter
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            if (args.Length > 0)
            {
                if (args[0].ToLower() == "/s")
                {
                    Process p = new Process();
                    p.StartInfo.FileName = System.AppDomain.CurrentDomain.FriendlyName.Substring(0, System.AppDomain.CurrentDomain.FriendlyName.Length - 4) + ".exe";
                    p.Start();
                }
                else if (args[0].ToLower().Contains("/c") == true)
                {
                    MessageBox.Show("This Screen Saver has no settings to setup.");
                }
            }
        }
    }
}
